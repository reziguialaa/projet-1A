#ifndef ANIM_H_
#define ANIM_H_
void HandleEvent(SDL_Event event,int gameover,SDL_Rect rcSrc,SDL_Rect rcSprite);

#endif
