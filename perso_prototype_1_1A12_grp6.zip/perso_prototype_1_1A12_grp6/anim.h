#ifndef ANIM_H_
#define ANIM_H_
void gestionevent(SDL_Event *event,SDL_Rect *rcSrc, SDL_Rect *rcSprite,int *gameover);
void saut(SDL_Rect *rcSrc, SDL_Rect *rcSprite);
#endif
