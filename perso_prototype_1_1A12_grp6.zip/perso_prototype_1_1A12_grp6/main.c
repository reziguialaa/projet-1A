#include <SDL/SDL.h>
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL_image.h>
#include "perso.h"

int gameover;

/* source/destination */
perso p;

int main ( int argc, char *argv[] )
{
  SDL_Surface *screen, *temp, *sprite, *grass;
  SDL_Rect rcGrass;
  int colorkey,cont=1,i=70;

  /* initialisation SDL */
  SDL_Init(SDL_INIT_VIDEO);

  /* captions */
  SDL_WM_SetCaption("SDL Animation", "SDL Animation");

  /* fenêtre */
  screen = SDL_SetVideoMode(1120, 960, 0, 0);

  /* key hold */
  SDL_EnableKeyRepeat(60,60);

  /* load sprite */
  temp   = SDL_LoadBMP("sprite.bmp");
  sprite = SDL_DisplayFormat(temp);
  SDL_FreeSurface(temp);

  /* setup sprite /utilisation de RLE */
  colorkey = SDL_MapRGB(screen->format, 255, 0, 255);
  SDL_SetColorKey(sprite, SDL_SRCCOLORKEY | SDL_RLEACCEL, colorkey);

  /* load grass (background) */
  temp  = SDL_LoadBMP("grass.bmp");
  grass = SDL_DisplayFormat(temp);
  SDL_FreeSurface(temp);

  init(&p);
  gameover = 0;

  /* boucle du jeu */
  while (!gameover)
  {
    SDL_Event event;

    /* gestion des events */
    if (SDL_PollEvent(&event)) {
      gestionevent(&event,&p, &gameover);
    }

    /* collision avec xmax / ymax*/
    if ( p.rcSprite.x < 0 ) {
      p.rcSprite.x = 0;
    }
    else if ( p.rcSprite.x > 1120-32 ) {
      p.rcSprite.x = 1120-32;
    }
    if ( p.rcSprite.y < 0 ) {
      p.rcSprite.y = 0;
    }
    else if ( p.rcSprite.y > 960-32 ) {
      p.rcSprite.y = 960-32;
    }

    /* affichage du map (background) */
    for (int x = 0; x < 1280 / 32; x++) {
      for (int y = 0; y < 960 / 32; y++) {
        rcGrass.x = x * 32;
        rcGrass.y = y * 32;
        SDL_BlitSurface(grass, NULL, screen, &rcGrass);
      }
    }
    /* affichage du sprite */
    SDL_BlitSurface(sprite, &(p).rcSrc, screen, &(p).rcSprite);

    /* mise a jours ecran */
    SDL_Flip(screen);
  }

  /* clean up */
  SDL_FreeSurface(sprite);
  SDL_FreeSurface(grass);
  SDL_Quit();

  return 0;
}
