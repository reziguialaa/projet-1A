#include <SDL/SDL.h>
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL_image.h>
#include "perso.h"
//#include <math.h>

int gameover;

/* source/destination */
perso p,p1;

int main ( int argc, char *argv[] )
{
  SDL_Surface *screen, *temp, *sprite, *grass;
  SDL_Rect rcGrass;
  int colorkey,cont=1;

  /* initialisation SDL */
  SDL_Init(SDL_INIT_VIDEO);

  /* captions */
  SDL_WM_SetCaption("SDL Animation", "SDL Animation");

  /* fenêtre */
  screen = SDL_SetVideoMode(1120, 960, 0, 0);

  /* key hold */
  SDL_EnableKeyRepeat(60,60);

  /* load sprite */
  /*temp   = IMG_Load("perso.png");
  sprite = SDL_DisplayFormat(temp);
  SDL_FreeSurface(temp);*/
init(&p,&p1,screen);

  /* setup sprite /utilisation de RLE */
  /*colorkey = SDL_MapRGBA(screen->format, 255, 255, 255,255);
  SDL_SetColorKey(p.sprite, SDL_SRCCOLORKEY | SDL_RLEACCEL, colorkey);*/

  /* load grass (background) */
  temp  = SDL_LoadBMP("grass.bmp");
  grass = SDL_DisplayFormat(temp);
  SDL_FreeSurface(temp);

  gameover = 0;

  /* boucle du jeu */
  while (!gameover)
  {
    SDL_Event event;

    /* gestion des events */
    if (SDL_PollEvent(&event)) {
      gestionevent(&event,&p,&p1, &gameover);
    }

    /* collision avec xmax / ymax*/
    if ( p.rcSprite.x < 0 ) {
      p.rcSprite.x = 0;
    }
    else if ( p.rcSprite.x > 1120-60 ) {
      p.rcSprite.x = 1120-60;
    }
    if ( p.rcSprite.y < 0 ) {
      p.rcSprite.y = 0;
    }
    else if ( p.rcSprite.y > 960-54 ) {
      p.rcSprite.y = 960-54;
    }
//////////////avec p1
if ( p1.rcSprite.x < 0 ) {
      p1.rcSprite.x = 0;
    }
    else if ( p.rcSprite.x > 1120-60 ) {
      p1.rcSprite.x = 1120-60;
    }
    if ( p.rcSprite.y < 0 ) {
      p1.rcSprite.y = 0;
    }
    else if ( p.rcSprite.y > 960-54 ) {
      p1.rcSprite.y = 960-54;
    }

    /* affichage du map (background) */
    for (int x = 0; x < 1280 / 32; x++) {
      for (int y = 0; y < 960 / 32; y++) {
        rcGrass.x = x * 32;
        rcGrass.y = y * 32;
        SDL_BlitSurface(grass, NULL, screen, &rcGrass);
      }
    }
    /* affichage du sprite */
    SDL_BlitSurface(p.sprite, &(p).rcSrc, screen, &(p).rcSprite);
    SDL_BlitSurface(p1.sprite, &(p1).rcSrc, screen, &(p1).rcSprite);

    /* mise a jours ecran */
    SDL_Flip(screen);
  }

  /* clean up */
  SDL_FreeSurface(p.sprite);
  SDL_FreeSurface(grass);
  SDL_Quit();

  return 0;
}
