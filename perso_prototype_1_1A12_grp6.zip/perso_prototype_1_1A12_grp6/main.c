#include <SDL/SDL.h>
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL_image.h>
#include "anim.h"
#define SCREEN_WIDTH  640
#define SCREEN_HEIGHT 480
#define TAILLE_SPRITE    32

int gameover;

/* source/destination */
SDL_Rect rcSrc, rcSprite;

int main ( int argc, char *argv[] )
{
  SDL_Surface *screen, *temp, *sprite, *grass;
  SDL_Rect rcGrass;
  int colorkey,cont=1,i=70;

  /* initialisation SDL */
  SDL_Init(SDL_INIT_VIDEO);

  /* captions */
  SDL_WM_SetCaption("SDL Animation", "SDL Animation");

  /* fenêtre */
  screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 0, 0);

  /* key hold */
  SDL_EnableKeyRepeat(i,i);

  /* load sprite */
  temp   = SDL_LoadBMP("sprite.bmp");
  sprite = SDL_DisplayFormat(temp);
  SDL_FreeSurface(temp);

  /* setup sprite /utilisation de RLE */
  colorkey = SDL_MapRGB(screen->format, 255, 0, 255);
  SDL_SetColorKey(sprite, SDL_SRCCOLORKEY | SDL_RLEACCEL, colorkey);

  /* load grass (background) */
  temp  = SDL_LoadBMP("grass.bmp");
  grass = SDL_DisplayFormat(temp);
  SDL_FreeSurface(temp);

  /* set sprite position */
  rcSprite.x = 150;
  rcSprite.y = 150;

  /* frame */
  rcSrc.x = 128;
  rcSrc.y = 0;
  rcSrc.w = TAILLE_SPRITE;
  rcSrc.h = TAILLE_SPRITE;

  gameover = 0;

  /* boucle du jeu */
  while (!gameover)
  {
    SDL_Event event;

    /* gestion des events */
    if (SDL_PollEvent(&event)) {
      gestionevent(&event,&rcSrc,  &rcSprite, &gameover);
    }

    /* collision avec xmax / ymax*/
    if ( rcSprite.x < 0 ) {
      rcSprite.x = 0;
    }
    else if ( rcSprite.x > SCREEN_WIDTH-TAILLE_SPRITE ) {
      rcSprite.x = SCREEN_WIDTH-TAILLE_SPRITE;
    }
    if ( rcSprite.y < 0 ) {
      rcSprite.y = 0;
    }
    else if ( rcSprite.y > SCREEN_HEIGHT-TAILLE_SPRITE ) {
      rcSprite.y = SCREEN_HEIGHT-TAILLE_SPRITE;
    }

    /* affichage du map (background) */
    for (int x = 0; x < SCREEN_WIDTH / TAILLE_SPRITE; x++) {
      for (int y = 0; y < SCREEN_HEIGHT / TAILLE_SPRITE; y++) {
        rcGrass.x = x * TAILLE_SPRITE;
        rcGrass.y = y * TAILLE_SPRITE;
        SDL_BlitSurface(grass, NULL, screen, &rcGrass);
      }
    }
    /* affichage du sprite */
    SDL_BlitSurface(sprite, &rcSrc, screen, &rcSprite);

    /* mise a jours ecran */
    SDL_UpdateRect(screen, 0, 0, 0, 0);
  }

  /* clean up */
  SDL_FreeSurface(sprite);
  SDL_FreeSurface(grass);
  SDL_Quit();

  return 0;
}
