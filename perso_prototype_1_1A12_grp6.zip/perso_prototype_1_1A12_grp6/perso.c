#include <SDL/SDL.h>
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL_image.h>
#include "perso.h"
void init(perso *p,perso *p1,SDL_Surface *screen)
{
	int colorkey;
	SDL_Surface *temp;
  temp= IMG_Load("perso.png");
  p->sprite = SDL_DisplayFormat(temp);
  SDL_FreeSurface(temp);
  /*position initial*/
  p->rcSprite.x = 150;
  p->rcSprite.y = 150;
  //frame
  p->rcSrc.x = 0;
  p->rcSrc.y = 0;
  p->rcSrc.w = 60;
  p->rcSrc.h = 45;
	  colorkey = SDL_MapRGBA(screen->format, 0, 0, 0,0);
  SDL_SetColorKey(p->sprite, SDL_SRCCOLORKEY | SDL_RLEACCEL, colorkey);

//////////////////////////////////////////////////////////////////////////
SDL_Surface *temp1;
  temp1= IMG_Load("perso.png");
  p1->sprite = SDL_DisplayFormat(temp1);
  SDL_FreeSurface(temp1);
  /*position initial*/
  p1->rcSprite.x = 100;
  p1->rcSprite.y = 150;
  //frame
  p1->rcSrc.x = 0;
  p1->rcSrc.y = 0;
  p1->rcSrc.w = 60;
  p1->rcSrc.h = 45;
	  colorkey = SDL_MapRGBA(screen->format, 0, 0, 0,0);
  SDL_SetColorKey(p1->sprite, SDL_SRCCOLORKEY | SDL_RLEACCEL, colorkey);


}

void affichage(SDL_Event *event,perso *p)
{
switch ((*event).key.keysym.sym) {
    /* affichage */
        case SDLK_RIGHT:
          if ( (p->rcSrc.x == 0)&&(p->rcSrc.y == 0) ) //changer le sprite affiché
            p->rcSrc.x = 60;
          else if ( (p->rcSrc.x == 60)&&(p->rcSrc.y == 0) )
            p->rcSrc.x = 120;
	else if ( (p->rcSrc.x == 120)&&(p->rcSrc.y == 0) )
	 p->rcSrc.x = 180;
	else if ( (p->rcSrc.x == 180)&&(p->rcSrc.y == 0) )
	 p->rcSrc.x = 240;
	else if ( (p->rcSrc.x == 240)&&(p->rcSrc.y == 0) )
	 p->rcSrc.x = 300;
	else
	       {
			p->rcSrc.x = 60;
		        p->rcSrc.y = 0;
		}
          break;



        case SDLK_LEFT:
          if (( p->rcSrc.x == 120)&&(p->rcSrc.y == 50) )
            p->rcSrc.x = 180;
          else if ( (p->rcSrc.x == 180)&&(p->rcSrc.y == 50) )
            p->rcSrc.x = 240;
	else if ( (p->rcSrc.x == 240)&&(p->rcSrc.y == 50) )
            p->rcSrc.x = 300;
	else if ( (p->rcSrc.x == 300)&&(p->rcSrc.y == 50) )
                {
			p->rcSrc.x = 0;
			p->rcSrc.y = 98;
		}
	else if ( (p->rcSrc.x == 0)&&(p->rcSrc.y == 98) )
                {
			p->rcSrc.x = 60;
			p->rcSrc.y = 98;
		}		
	else
       	  {
		p->rcSrc.y =50;	
		p->rcSrc.x =180;
          }
	break;



	case SDLK_d:
          if ( (p->rcSrc.x == 0)&&(p->rcSrc.y == 0) ) //changer le sprite affiché
            p->rcSrc.x = 60;
          else if ( (p->rcSrc.x == 60)&&(p->rcSrc.y == 0) )
            p->rcSrc.x = 120;
	else if ( (p->rcSrc.x == 120)&&(p->rcSrc.y == 0) )
	 p->rcSrc.x = 180;
	else if ( (p->rcSrc.x == 180)&&(p->rcSrc.y == 0) )
	 p->rcSrc.x = 240;
	else if ( (p->rcSrc.x == 240)&&(p->rcSrc.y == 0) )
	 p->rcSrc.x = 300;
	else
	       {
			p->rcSrc.x = 60;
		        p->rcSrc.y = 0;
		}
          break;



        case SDLK_q:
          if (( p->rcSrc.x == 120)&&(p->rcSrc.y == 50) )
            p->rcSrc.x = 180;
          else if ( (p->rcSrc.x == 180)&&(p->rcSrc.y == 50) )
            p->rcSrc.x = 240;
	else if ( (p->rcSrc.x == 240)&&(p->rcSrc.y == 50) )
            p->rcSrc.x = 300;
	else if ( (p->rcSrc.x == 300)&&(p->rcSrc.y == 50) )
                {
			p->rcSrc.x = 0;
			p->rcSrc.y = 98;
		}
	else if ( (p->rcSrc.x == 0)&&(p->rcSrc.y == 98) )
                {
			p->rcSrc.x = 60;
			p->rcSrc.y = 98;
		}		
	else
       	  {
		p->rcSrc.y =50;	
		p->rcSrc.x =180;
          }
	break;

}}
/////////////////////////////////////////////////////
void deplacement(SDL_Event *event,perso *p)
{
	switch ((*event).key.keysym.sym) {
    /* mouvement*/
        case SDLK_LEFT:
          p->rcSprite.x = p->rcSprite.x-5;
          break;
        case SDLK_RIGHT:
          p->rcSprite.x += 5;
          break;
	case SDLK_q:
          p->rcSprite.x = p->rcSprite.x-5;
          break;
        case SDLK_d:
          p->rcSprite.x += 5;
          break;
}
}

/////////////////////////////////////////////////
void saut(SDL_Rect *rcSrc, SDL_Rect *rcSprite)
{
	if((((*rcSrc).x == 0)||((*rcSrc).x == 60)||((*rcSrc).x == 120)||((*rcSrc).x == 180)||((*rcSrc).x == 240)||((*rcSrc).x == 300))&&(((*rcSrc).y == 0)))
	{
		(*rcSprite).x=(*rcSprite).x+32;
		(*rcSprite).y=(*rcSprite).y-32;
	}
	else if((((*rcSrc).x == 120)||((*rcSrc).x == 0)||((*rcSrc).x == 60)||((*rcSrc).x == 180)||((*rcSrc).x == 240)||((*rcSrc).x == 300))&&(((*rcSrc).y == 98)||((*rcSrc).y == 180)||(*rcSrc).y == 50))
	{
		(*rcSprite).x=(*rcSprite).x-32;
		(*rcSprite).y=(*rcSprite).y-32;
	}

}
///////////////////////////////////////////////////////////////////////////////////////////
void gestionevent(SDL_Event *event,perso *p,perso *p1,int *gameover)
{
  switch ((*event).type) {
    /* quitter */
    case SDL_QUIT:
      *gameover = 1;
      break;

    /* clavier  */
    case SDL_KEYDOWN:
      switch ((*event).key.keysym.sym) {
        case SDLK_ESCAPE:
          *gameover = 1;
          break;
    /* affichage && mouvement*/
        case SDLK_LEFT:
          affichage(event,p);
	  deplacement(event,p);
          break;
        case SDLK_RIGHT:
          affichage(event,p);
	  deplacement(event,p);
          break;
	/////////////////////////////////
	case SDLK_d:
          affichage(event,p1);
	  deplacement(event,p1);
          break;
        case SDLK_q:
          affichage(event,p1);
	  deplacement(event,p1);
          break;
	/////////////////////////////////
    /* jump */
	case SDLK_SPACE:
	if((p->rcSprite).y!=0)
	{
		saut(&p->rcSrc,&p->rcSprite);
	}	
	break;
	case SDLK_j:
	if((p->rcSprite).y!=0)
	{
		saut(&p1->rcSrc,&p1->rcSprite);
	}	
	break;
      }
      break;
	case SDL_KEYUP:
	switch((*event).key.keysym.sym)
	{
		case SDLK_SPACE:
	if((p->rcSprite).y!=0)
	(p->rcSprite).y=(p->rcSprite).y+32;
	break;
		case SDLK_j:
	if((p1->rcSprite).y!=0)
	(p1->rcSprite).y=(p1->rcSprite).y+32;
	break;
	}
	break;
  }
}
