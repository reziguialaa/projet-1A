#include <SDL/SDL.h>
#include "perso.h"

void init(perso *p)
{
  /*position initial*/
  p->rcSprite.x = 150;
  p->rcSprite.y = 150;
  //frame
  p->rcSrc.x = 128;
  p->rcSrc.y = 0;
  p->rcSrc.w = 32;
  p->rcSrc.h = 32;

}

void affichage(SDL_Event *event,SDL_Rect *rcSrc)
{
switch ((*event).key.keysym.sym) {
    /* affichage */
        case SDLK_LEFT:
          if ( (*rcSrc).x == 192 ) //changer le sprite affiché
            (*rcSrc).x = 224;
          else
            (*rcSrc).x = 192;          
          break;
        case SDLK_RIGHT:
          if ( (*rcSrc).x == 64 )
            (*rcSrc).x = 96;
          else
            (*rcSrc).x = 64;
          break;
        case SDLK_UP:
          if ( (*rcSrc).x == 0 )
            (*rcSrc).x = 32;
          else
            (*rcSrc).x = 0;
          break;
        case SDLK_DOWN:
          if ( (*rcSrc).x == 128 )
            (*rcSrc).x = 160;
          else
            (*rcSrc).x = 128;
          break;
}}
/////////////////////////////////////////////////////
void deplacement(SDL_Event *event,SDL_Rect *rcSprite)
{
	switch ((*event).key.keysym.sym) {
    /* mouvement*/
        case SDLK_LEFT:
          (*rcSprite).x -= 5;
          break;
        case SDLK_RIGHT:
          (*rcSprite).x += 5;
          break;
        case SDLK_UP:
          (*rcSprite).y -= 5;
          break;
        case SDLK_DOWN:
          (*rcSprite).y += 5;
          break;
}
}

/////////////////////////////////////////////////
void saut(SDL_Rect *rcSrc, SDL_Rect *rcSprite)
{
	if(((*rcSrc).x == 224)||((*rcSrc).x == 192))
	{
		(*rcSprite).x=(*rcSprite).x-32;
		(*rcSprite).y=(*rcSprite).y-32;
	}
	else if(((*rcSrc).x == 96)||((*rcSrc).x == 64))
	{
		(*rcSprite).x=(*rcSprite).x+32;
		(*rcSprite).y=(*rcSprite).y-32;
	}
	else if(((*rcSrc).x==160)||((*rcSrc).x==128))
	{
		(*rcSprite).y=(*rcSprite).y+32;
	}

}
///////////////////////////////////////////////////////////////////////////////////////////
void gestionevent(SDL_Event *event,perso *p,int *gameover)
{
  switch ((*event).type) {
    /* quitter */
    case SDL_QUIT:
      *gameover = 1;
      break;

    /* clavier  */
    case SDL_KEYDOWN:
      switch ((*event).key.keysym.sym) {
        case SDLK_ESCAPE:
        case SDLK_q:
          *gameover = 1;
          break;
    /* affichage && mouvement*/
        case SDLK_LEFT:
          affichage(event,&p->rcSrc);
	  deplacement(event,&p->rcSprite);
          break;
        case SDLK_RIGHT:
          affichage(event,&p->rcSrc);
	  deplacement(event,&p->rcSprite);
          break;
        case SDLK_UP:
          affichage(event,&p->rcSrc);
	  deplacement(event,&p->rcSprite);
          break;
        case SDLK_DOWN:
          affichage(event,&p->rcSrc);
	  deplacement(event,&p->rcSprite);
          break;
    /* jump */
	case SDLK_SPACE:
	if((p->rcSprite).y!=0)
	{
		saut(&p->rcSrc,&p->rcSprite);
	}	
	break;
      }
      break;
	case SDL_KEYUP:
	switch((*event).key.keysym.sym)
	{
		case SDLK_SPACE:
	if((p->rcSprite).y!=0)
	if(((p->rcSrc).x!=160)&&((p->rcSrc).x!=128)&&((p->rcSrc).x!=0)&&((p->rcSrc).x!=32))
	(p->rcSprite).y=(p->rcSprite).y+32;
	break;
	}
	break;
  }
}
