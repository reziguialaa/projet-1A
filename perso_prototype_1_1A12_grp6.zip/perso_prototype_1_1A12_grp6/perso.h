#ifndef ANIM_H_
#define ANIM_H_
typedef struct
{
	
	SDL_Rect rcSrc;
	SDL_Rect rcSprite;
	SDL_Surface *sprite;
}perso;
void init(perso *p,perso *p1,SDL_Surface *screen);
void gestionevent(SDL_Event *event,perso *p,perso *p1,int *gameover);
void saut(SDL_Rect *rcSrc, SDL_Rect *rcSprite);
void affichage(SDL_Event *event,perso *p);
void deplacement(SDL_Event *event,perso *p);
#endif
