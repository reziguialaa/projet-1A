#ifndef ANIM_H_
#define ANIM_H_
typedef struct
{
	SDL_Rect rcSrc;
	SDL_Rect rcSprite;
}perso;
void init(perso *p);
void gestionevent(SDL_Event *event,perso *p,int *gameover);
void saut(SDL_Rect *rcSrc, SDL_Rect *rcSprite);
void affichage(SDL_Event *event,SDL_Rect *rcSrc);
void deplacement(SDL_Event *event,SDL_Rect *rcSprite);
#endif
